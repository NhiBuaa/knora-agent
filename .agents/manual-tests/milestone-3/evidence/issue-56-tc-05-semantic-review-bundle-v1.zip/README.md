# Issue #56 TC-05 independent semantic-review bundle

Frozen calibration manifest SHA-256: `692eac26a4d4857bb7fd147213ca8b5691961b3b4878f7dc915bda55ef281f07`.

This read-only bundle contains the complete frozen calibration manifest and every member, the complete 50-case m3-dataset-v1 release, every m3-corpus-v1 document and manifest, review inventories, and the complete deterministic comparison population. It contains no provider credential, provider response, embedding, score, candidate, or calibration result.

The reviewer must inspect all sources, questions, facts, and judgments for copying, rephrasing, or derivation. Return a separate JSON attestation satisfying review/reviewer-attestation.schema.json with PASS, FAIL, or INDETERMINATE. Do not edit this bundle.
